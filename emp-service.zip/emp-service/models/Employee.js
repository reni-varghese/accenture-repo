const db = require("../util/database");

class Employee {
  constructor(id, name, gender, age, salary) {
    this.id = id;
    this.name = name;
    this.gender = gender;
    this.age = age;
    this.salary = salary;
  }

  save() {
    return db.execute("INSERT INTO employees VALUES(?,?,?,?,?)", [
      this.id,
      this.name,
      this.gender,
      this.age,
      this.salary,
    ]);
  }
  static fetchAll() {
    return db.execute("SELECT * FROM employees");
  }
  static findById(id) {
    return db.execute("SELECT * FROM employees where id=?", [id]);
  }
}

module.exports = Employee;
