const userName = ["Manu", "Varma"];

// const [firstName, lastName] = userName;

// console.log(firstName);
// console.log(lastName);

const employee = {
  firstName: "Manu",
  lastName: "Varma",
  age: 23,
  salary: 56000,
};

const { firstName, lastName, salary } = employee;
console.log(firstName);
console.log(salary);
