const express = require("express");
const router = require("./routes/router");
const handlebars = require("express-handlebars");

const app = express();
app.use(express.urlencoded({ extended: true }));

app.use(express.static("public"));

app.engine("handlebars", handlebars.engine());
app.set("view engine", "handlebars");
app.set("views", "views");

app.use(router);

app.listen(8000, () => {
  console.log("Employee Client started @ PORT 8000");
});
