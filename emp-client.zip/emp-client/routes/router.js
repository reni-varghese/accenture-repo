const express = require("express");
const { getAll } = require("../apis/employee-api");
const employeeController = require("../controllers/employeeController");
const {
  getAllEmployees,
  showAddForm,
  add,
  showUpdateForm,
  update,
  deleteEmp,
} = require("../controllers/employeeController");

const router = express.Router();

router.get("/", getAllEmployees);
router.get("/add", showAddForm);
router.post("/add-employee", add);
router.get("/update", showUpdateForm);
router.post("/update-employee", update);
router.get("/delete", deleteEmp);

module.exports = router;
