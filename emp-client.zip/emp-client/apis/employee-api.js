const axios = require("axios");

const getAll = async () => {
  const response = await axios.get("http://localhost:5000/api/employees");
  return response.data;
};

const addEmployee = async (employee) => {
  const response = await axios.post(
    "http://localhost:5000/api/employees",
    employee
  );
  return response.data;
};
const getById = async (id) => {
  const response = await axios.get(`http://localhost:5000/api/employees/${id}`);
  console.log(response.data);
  return response.data;
};

const updateEmployee = async (id, employee) => {
  const response = await axios.put(
    `http://localhost:5000/api/employees/${id}`,
    employee
  );
  return response.data;
};
const deleteEmployee = async (id) => {
  const response = await axios.delete(
    `http://localhost:5000/api/employees/${id}`
  );
  return response.data;
};
module.exports = {
  getAll,
  addEmployee,
  getById,
  updateEmployee,
  deleteEmployee,
};
