const {
  getAll,
  addEmployee,
  getById,
  updateEmployee,
  deleteEmployee,
} = require("../apis/employee-api");

const getAllEmployees = async (req, res) => {
  const employees = await getAll();
  res.render("index", { employees, pageTitle: "Employee Details" });
};
const showAddForm = (req, res) => {
  res.render("add");
};
const add = async (req, res) => {
  const body = req.body;
  console.log(body);
  const result = await addEmployee(body);
  res.redirect("/");
};

const showUpdateForm = async (req, res) => {
  const id = req.query.id;
  console.log(id);
  const employee = await getById(+id);
  console.log(employee);
  res.render("update", {
    employee,
    isMale: employee.gender === "Male",
    isFemale: employee.gender === "Female",
  });
};
const update = async (req, res) => {
  const body = req.body;
  console.log(body);

  const result = await updateEmployee(body.id, body);
  res.redirect("/");
};

const deleteEmp = async (req, res) => {
  const id = req.query.id;
  const result = await deleteEmployee(+id);
  res.redirect("/");
};

module.exports = {
  getAllEmployees,
  showAddForm,
  add,
  showUpdateForm,
  update,
  deleteEmp,
};
