const path = require("path");
const express = require("express");
const router = require("./routes/router");

const app = express();
app.use(express.urlencoded({ extended: true }));

app.use(router);

app.use((req, res) => {
  res.status(404).sendFile(path.join(__dirname, "views", "404.html"));
});

app.listen(5000, () => {
  console.log("Server started @ PORT 5000");
});
