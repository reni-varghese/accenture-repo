const fs = require("fs");
const path = require("path");
const express = require("express");

const router = express.Router();

router.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "..", "views", "index.html"));
});

router.post("/add-product", (request, response) => {
  const product = request.body;
  fs.appendFileSync("products.txt", product.title + "\r\n");
  response.redirect("/status");
});

router.get("/status", (req, res) => {
  res.send("<h3>Product saved</h3>");
});
router.get("/myfile", (req, res) => {
  res.sendFile(path.join(__dirname, "myfile.html"));
});

module.exports = router;
