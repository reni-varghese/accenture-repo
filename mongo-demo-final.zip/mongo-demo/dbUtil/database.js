const mongodb = require("mongodb");

const MongoClient = mongodb.MongoClient;
let db;

MongoClient.connect("mongodb://localhost/accdb")
  .then((client) => {
    db = client.db();
    console.log("Connected to MongoDb");
  })
  .catch((error) => console.log(error));

function getDb() {
  return db;
}

module.exports = getDb;
