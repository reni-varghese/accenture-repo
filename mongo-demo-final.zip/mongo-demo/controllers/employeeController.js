const Employee = require("../models/Employee");

const getAll = async (req, res) => {
  try {
    const employees = await Employee.fetchAll();

    console.log(employees);

    res.send(employees);
  } catch (error) {
    console.log(error);
  }
};

const getById = async (req, res) => {
  const id = req.params.id;
  try {
    const employee = await Employee.findById(+id);
    console.log(employee);
    res.send(employee);
  } catch (error) {
    console.log(error);
  }
};

const add = async (req, res) => {
  const body = req.body;
  const employee = new Employee(
    body._id,
    body.name,
    body.gender,
    body.age,
    body.salary
  );
  try {
    const result = await employee.save();
    res.status(201).send(`Employee with id ${body._id} saved successfully`);
  } catch (error) {
    console.log(error);
  }
};

const deleteEmp = async (req, res) => {
  const id = req.params.id;

  try {
    const emp = await Employee.findById(+id);
    if (emp) {
      const result = Employee.deleteById(+id);
      res.send(`Employee with id ${id} deleted successfully`);
    } else {
      res.status(404).send(`Employee with id ${id} not found`);
    }
  } catch (error) {
    console.log(error);
  }
};

const update = async (req, res) => {
  const id = req.params.id;
  const body = req.body;
  try {
    const emp = await Employee.findById(+id);
    if (emp) {
      if (body.name) {
        emp.name = body.name;
      }
      if (body.gender) {
        emp.gender = body.gender;
      }
      if (body.age) {
        emp.age = body.age;
      }
      if (body.salary) {
        emp.salary = body.salary;
      }
      const employee = new Employee(
        +id,
        emp.name,
        emp.gender,
        emp.age,
        emp.salary
      );
      const result = await employee.update();
      res.send(`Employee with id ${id} updated successfully`);
    } else {
      res.status(404).send(`Employee with id ${id} not found`);
    }
  } catch (error) {}
};

module.exports = {
  getAll,
  getById,
  add,
  deleteEmp,
  update,
};
