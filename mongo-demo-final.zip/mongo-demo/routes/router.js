const express = require("express");
const Employee = require("../models/Employee");
const employeeController = require("../controllers/employeeController");

const router = express.Router();

router.get("/api/employees", employeeController.getAll);

router.get("/api/employees/:id", employeeController.getById);

router.post("/api/employees", employeeController.add);

router.delete("/api/employees/:id", employeeController.deleteEmp);

router.put("/api/employees/:id", employeeController.update);

module.exports = router;
