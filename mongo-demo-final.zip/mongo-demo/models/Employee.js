const getDb = require("../dbUtil/database");
const { get } = require("../routes/router");

class Employee {
  constructor(id, name, gender, age, salary) {
    this._id = id;
    this.name = name;
    this.gender = gender;
    this.age = age;
    this.salary = salary;
  }

  static fetchAll() {
    const db = getDb();
    return db.collection("employees").find().toArray();
  }
  static findById(id) {
    let db = getDb();
    return db.collection("employees").findOne({ _id: id });
  }
  save() {
    let db = getDb();
    return db.collection("employees").insertOne(this);
  }
  static deleteById(id) {
    let db = getDb();
    return db.collection("employees").deleteOne({ _id: id });
  }

  update() {
    let db = getDb();
    return db
      .collection("employees")
      .updateOne({ _id: this._id }, { $set: this });
  }
}

module.exports = Employee;
