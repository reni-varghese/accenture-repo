const db = require("../util/database");

class Employee {
  constructor(id, name, gender, age, salary) {
    this.id = id;
    this.name = name;
    this.gender = gender;
    this.age = age;
    this.salary = salary;
  }

  save() {
    return db.execute("INSERT INTO employees VALUES(?,?,?,?,?)", [
      this.id,
      this.name,
      this.gender,
      this.age,
      this.salary,
    ]);
  }
  static fetchAll() {
    return db.execute("SELECT * FROM employees");
  }
  static findById(id) {
    return db.execute("SELECT * FROM employees where id=?", [id]);
  }
  static deleteById(id) {
    return db.execute("DELETE FROM employees WHERE id=?", [id]);
  }
  update() {
    console.log("This", this);
    return db.execute(
      "update employees set name=?,gender=?,age=?,salary=? where id=?",
      [this.name, this.gender, this.age, this.salary, this.id]
    );
  }
}

module.exports = Employee;
