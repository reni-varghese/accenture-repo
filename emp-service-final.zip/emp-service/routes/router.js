const express = require("express");
const Employee = require("../models/Employee");

const router = express.Router();

router.get("/api/employees", (req, res) => {
  Employee.fetchAll()
    .then((result) => {
      console.log(result);
      const employees = result[0];
      res.send(employees);
    })
    .catch((err) => console.log(err));
});
router.post("/api/employees", (req, res) => {
  const emp = req.body;
  console.log(emp);
  const employee = new Employee(
    emp.id,
    emp.name,
    emp.gender,
    emp.age,
    emp.salary
  );
  employee
    .save()
    .then((result) => {
      console.log(result);
      res
        .status(201)
        .send("Employee with id " + emp.id + " saved successfully");
    })
    .catch((err) => console.log(err));
});
router.get("/api/employees/:id", async (req, res) => {
  const id = req.params.id;
  try {
    const result = await Employee.findById(+id);
    console.log(result);
    const [employee] = result[0];
    if (!employee) {
      return res.status(404).send(`Employee with Id ${id} not found`);
    }

    res.send(employee);
  } catch (error) {
    console.log(error);
  }
});
router.delete("/api/employees/:id", async (req, res) => {
  const id = req.params.id;
  //const empId=parseInt(id);
  try {
    const emp = await Employee.findById(+id);
    if (emp) {
      Employee.deleteById(+id)
        .then((result) => {
          res.send(`Employee with ${id} deleted successfully`);
        })
        .catch((err) => console.log(err));
    } else {
      res.status(404).send(`Employee with id ${id} not found`);
    }
  } catch (error) {
    console.log(error);
  }
});

router.put("/api/employees/:id", async (req, res) => {
  const id = req.params.id;
  const body = req.body;
  console.log("Body", body);

  try {
    let result = await Employee.findById(+id);
    const [emp] = result[0];
    console.log(emp);
    if (body.name) {
      emp.name = body.name;
    }
    if (body.gender) {
      emp.gender = body.gender;
    }
    if (body.age) {
      emp.age = body.age;
    }
    if (body.salary) {
      emp.salary = body.salary;
    }
    const employee = new Employee(
      +id,
      emp.name,
      emp.gender,
      emp.age,
      emp.salary
    );
    result = await employee.update();
    res.send(`Employee with Id ${id} updated successfully`);
  } catch (error) {
    console.log(error);
  }
});

module.exports = router;
