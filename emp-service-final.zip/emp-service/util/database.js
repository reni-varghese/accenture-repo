const mysql2 = require("mysql2");

const pool = mysql2.createPool({
  host: "localhost",
  database: "employeedb",
  user: "reni",
  password: "password",
});

module.exports = pool.promise();
