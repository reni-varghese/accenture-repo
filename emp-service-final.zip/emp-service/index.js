let employee = ["Manu", "Varma"];
const [firstName] = employee;

console.log(firstName);

