const employees = [
  { id: 1, name: "Manu", gender: "Male", age: 23, salary: 45000 },
  { id: 2, name: "Sara", gender: "Female", age: 22, salary: 87000 },
  { id: 3, name: "Sunil", gender: "Male", age: 44, salary: 98000 },
  { id: 4, name: "Anu", gender: "Female", age: 22, salary: 76000 },
  { id: 5, name: "Charu", gender: "Female", age: 21, salary: 35000 },
];

module.exports = employees;
