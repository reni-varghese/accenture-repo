const express = require("express");
const employees = require("../data/employees");

const router = express.Router();

router.get("/api/employees", (req, res) => {
  res.send(employees);
});

router.get("/api/employees/:id", (req, res) => {
  const id = req.params.id;
  //const newId=parseInt(id);
  console.log("id", id);
  const employee = employees.find((emp) => emp.id === +id);
  if (!employee) {
    return res.status(404).send(`Employee with id ${id} not found`);
  }
  return res.send(employee);

  res.send(employee);
});

router.post("/api/employees", (req, res) => {
  const employee = req.body;
  console.log(employee);
  employees.push(employee);
  res.status(201).send(`Employee with id ${employee.id} saved successfully`);
});

router.delete("/api/employees/:id", (req, res) => {
  const id = req.params.id;
  const index = employees.findIndex((emp) => emp.id === +id);
  if (index === -1) {
    return res.status(404).send(`Employee with id ${id} not found`);
  }
  employees.splice(index, 1);
  res.send(`Employee with id ${id} deleted successfully`);
});

router.put("/api/employees/:id", (req, res) => {
  const body = req.body;
  const id = req.params.id;
  const emp = employees.find((e) => e.id === +id);
  if (!emp) {
    return res.status(404).send(`Employee with id ${id} not found`);
  }
  if (body.name) {
    emp.name = body.name;
  }
  if (body.gender) {
    emp.gender = body.gender;
  }
  if (body.age) {
    emp.age = body.age;
  }
  if (body.salary) {
    emp.salary = body.salary;
  }
  res.send("Employee with id " + id + " updated successfully");
});

module.exports = router;
